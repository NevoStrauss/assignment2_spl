package bgu.spl.mics.application.messages;

import bgu.spl.mics.Broadcast;

/**
 * this broadcast sent from leia and indicates that all the attack events are sent.
 */
public class NoMoreAttacksBroadcast implements Broadcast {
}
